describe('Pokédex and Pokemon Details', () => {
  beforeEach(() => {
    cy.visit('http://localhost:5175/pokedex');
    cy.log('Visited the Pokédex page');
  });

  it('verifies the Pokédex page, navigates to Pokemon details, and returns to homescreen', () => {
    // Pokédex page assertions
    cy.get('.pokedex-page h1').should('be.visible');
    cy.log('Pokédex title is visible');

    cy.get('.search-bar').should('be.visible');
    cy.log('Search bar is visible');

    cy.get('[data-cy="pokemon-card"]', { timeout: 10000 }).should('have.length.at.least', 1);
    cy.log('At least one Pokemon card exists');

    // Click on the first Pokemon card, even if it's covered
    cy.get('[data-cy="pokemon-card"]').first().click({ force: true });
    cy.log('Clicked on the first Pokemon card');

    // Check if we've navigated to the Pokemon details page
    cy.url().should('include', '/pokemon/');
    cy.log('Navigated to Pokemon details page');

    // Pokemon Details page assertions
    cy.get('.pokemon-details-page').should('exist');
    cy.get('.pokemon-card').should('exist');

    cy.get('.pokemon-image-section img').should('be.visible');
    cy.log('Pokemon image is visible');

    cy.get('.pokemon-name').should('be.visible');
    cy.log('Pokemon name is visible');

    cy.get('.pokemon-details').within(() => {
      cy.contains('ID:').should('exist');
      cy.contains('Weight:').should('exist');
      cy.contains('Height:').should('exist');
      cy.contains('Base Experience:').should('exist');
    });
    cy.log('Basic Pokemon details are present');

    cy.get('.pokemon-types').should('exist');
    cy.get('.type-chip').should('have.length.at.least', 1);
    cy.log('Pokemon types are displayed');

    cy.get('.pokemon-abilities').should('exist');
    cy.get('.ability-chip').should('have.length.at.least', 1);
    cy.log('Pokemon abilities are displayed');

    cy.get('.pokemon-flavor-text').should('exist');
    cy.get('.pokemon-flavor-text p').should('not.be.empty');
    cy.log('Flavor text is present');

    // Test Favorite button functionality
    cy.get('.favorite-button').as('favoriteButton');
    cy.get('@favoriteButton').should('exist');
    cy.get('@favoriteButton').click();
    cy.get('@favoriteButton').should('have.class', 'favorite-button--active');
    cy.get('@favoriteButton').should('contain', 'Unfavorite');

// Wait for 2 seconds
    cy.wait(2000);

// Click again to unfavorite
    cy.get('@favoriteButton').click();
    cy.get('@favoriteButton').should('not.have.class', 'favorite-button--active');
    cy.get('@favoriteButton').should('contain', 'Favorite');
    cy.log('Favorite button functionality works');

    // Navigate to homescreen through navigation drawer
    cy.get('.v-app-bar-nav-icon').click();
    cy.log('Opened navigation drawer');

    cy.get('.v-navigation-drawer').should('be.visible');
    cy.log('Navigation drawer is visible');

    cy.contains('.v-list-item', 'Home Page').click();
    cy.log('Clicked on Home Page in navigation drawer');

// Check if we've navigated to the homepage
    cy.url().should('not.include', '/pokemon/');
    cy.log('Navigated away from Pokemon details page');

// Add assertions for the homepage here
    cy.get('.pokemon-news-section').should('exist');
    cy.get('.pokemon-of-the-week').should('be.visible');
    cy.get('.news-header').should('contain', 'Pokémon novinky');
    cy.log('Homepage is displayed');
  });
});

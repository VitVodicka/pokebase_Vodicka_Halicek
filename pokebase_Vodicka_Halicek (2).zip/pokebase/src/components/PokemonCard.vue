<template>
  <!-- v-card component that displays loading state based on the 'loading' variable -->
  <v-card :loading="loading">
    <!-- Conditionally renders content only if 'pokemon' data is available -->
    <template v-if="pokemon != null">
      <v-img :src="pokemon.sprites.front_default" height="180" /> <!-- Displays Pokemon image -->
      <v-card-title>{{ pokemon.name }}</v-card-title> <!-- Displays Pokemon name -->
      <v-card-text>
        <!-- Loops over Pokemon abilities and creates a chip for each ability -->
        <v-chip v-for="ability in pokemon.abilities" :key="ability.ability.name" color="primary" size="small">
          {{ ability.ability.name }}
        </v-chip>
      </v-card-text>
      <v-card-actions>
        <!-- Button to toggle favorite status, changes icon color if it's a favorite -->
        <v-btn icon @click="toggleFavorite">
          <v-icon :color="isFavorite ? 'yellow' : ''">mdi-star</v-icon>
        </v-btn>
      </v-card-actions>
    </template>
  </v-card>
</template>


<script setup lang="ts">
import { computed, ref, onMounted } from 'vue';
import { usePokemonStore } from '../stores/pokemons';
import { Pokemon } from '@/types';
import { api } from '@/api';

const props = defineProps<{ pokemonIdOrName: string | number }>(); // Defines component props

const pokemonStore = usePokemonStore(); // Accesses the Pokemon store

const loading = ref(false); // Reactive reference to track loading state
const pokemon = ref<Pokemon | null>(null); // Reactive reference to hold the current Pokemon data

// Function to toggle the favorite status of the Pokemon
const toggleFavorite = () => {
  if (pokemon.value != null) {
    pokemonStore.toggleFavorite(pokemon.value.id, pokemon.value.name);
  }
};

// Computed property to check if the current Pokemon is a favorite
const isFavorite = computed(() => {
  if (pokemon.value != null) {
    return pokemonStore.isFavorite(pokemon.value.id);
  }
  return false;
});

// Fetches Pokemon data when component is mounted
onMounted(() => {
  searchPokemon(props.pokemonIdOrName);
});

// Async function to fetch Pokemon data from the API
const searchPokemon = async (idOrName: string | number) => {
  loading.value = true; // Set loading to true before the API call

  try {
    const response = await api.get(`/pokemon/${idOrName}`); // Makes API request
    pokemon.value = response.data; // Sets fetched data to pokemon
  } catch (e) {
    console.error(`Pokemon "${idOrName}" not found.`); // Logs error if Pokemon is not found
  } finally {
    loading.value = false; // Resets loading state after API call
  }
};
</script>

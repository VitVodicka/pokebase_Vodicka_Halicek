<script setup lang="ts">
defineProps<{
  title: string;
}>()
</script>

<template>
  <v-card style="border-radius: 0%;">
    <v-layout>
      <v-app-bar style="background-color: hsl(226, 53%, 24%); color: hsl(0, 0%, 100%);">
        <v-app-bar-nav-icon variant="text" @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
        <v-toolbar-title class="d-none d-sm-flex">{{ title }}</v-toolbar-title>
        <v-spacer></v-spacer>
        <v-btn icon="mdi-export" variant="text"></v-btn>
      </v-app-bar>

      <v-navigation-drawer v-model="drawer" temporary style="background-color: hsl(223, 47%, 44%);">
        <v-list-tile>
          <v-list-tile-content>
            <v-list-tile-title>
              <div class="nav_drawer_icon">
                <router-link class="router_link" :to="{ name: 'homepage' }">
                  <v-img src="@/assets/pokeball.png" height="200" width="200" class="mx-auto"></v-img>
                </router-link>
                <div style="text-align: center; color: hsl(0, 0%, 100%)">Pokébase</div>
              </div>
            </v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
        <v-spacer></v-spacer>
        <div style="background-color: hsl(213, 57%, 45%); color: hsl(0, 0%, 100%); border-top: 1px solid black;">
          <template v-for="(item, i) in items" :key="item.value">
            <v-list-item style="padding: 0px" :to="{ name: item.value }" link>
              <template v-slot:default="{  }">
                <v-list-item-content>
                  <v-list-item-title style="padding-left: 10px;" v-text="item.title"></v-list-item-title>
                </v-list-item-content>
              </template>
            </v-list-item>
          </template>
        </div>
      </v-navigation-drawer>

      <v-main style="height: calc(100vh - 64px); overflow-y: auto;">
        <v-container fluid>
          <v-fade-transition mode="out-in">
            <slot name="page-contents"></slot>
          </v-fade-transition>
        </v-container>
      </v-main>
    </v-layout>
  </v-card>
</template>

<script lang="ts">
export default {
  data: () => ({
    drawer: false,
    group: null,
    items: [
      {
        title: 'Home Page',
        value: 'homepage',
        iconClass: 'icon-homepage'
      },
      {
        title: 'List of Generations',
        value: 'listofitems',
        iconClass: 'icon-loi'
      },
      {
        title: 'Pokédex',
        value: 'pokedex',
        iconClass: 'icon-pokedex'
      },
      {
        title: 'Quiz',
        value: 'quiz',
        iconClass: 'icon-quiz'
      },
      {
        title: 'About Us',
        value: 'aboutus',
        iconClass: 'icon-about'
      }
    ]
  }),

  watch: {
    group() {
      this.drawer = false
    }
  }
}
</script>

<style scoped>
.background {
  background-color: hsl(226, 53%, 24%);
  color: hsl(0, 0%, 100%);
}

.nav_drawer {
  padding-left: 10px;
  padding-right: 10px;
}

.nav_drawer_icon {
  padding-top: 10px;
  padding-bottom: 20px;
}

.router_link {
  display: flex;
  align-items: center;
}
</style>

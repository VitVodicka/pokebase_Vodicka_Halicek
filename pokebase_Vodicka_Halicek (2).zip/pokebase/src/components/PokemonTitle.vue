<template>
  <div class="gradient-background">
    <img :src="pokemonLogo" alt="Pokémon Logo" class="logo">
  </div>
</template>

<script setup lang="ts">
import pokemonLogo from '@/assets/pokemonlogo.png';
</script>

<style scoped>
.gradient-background {
  height: 25vh;
  background: linear-gradient(to bottom, #4a90e2, #142b56);
  display: flex;
  align-items: flex-start; /* Corrected from 'top' to 'flex-start' */
  justify-content: center;
  padding: 0 20px;
}

.logo {
  margin-top: 7vh;
  height: 60px;
  transform: scale(3);
}
</style>

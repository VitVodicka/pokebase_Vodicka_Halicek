export interface Ability {
  name: string;
  url: string;
}

export interface Move {
  name: string;
  url: string;
}

export interface Sprites {
  front_default: string;
  back_default: string;
  front_shiny: string;
  back_shiny: string;
}

export interface Type {
  name: string;
  url: string;
}

export interface Pokemon {
  id: number;
  name: string;
  weight: number;
  height: number;
  abilities: Array<{ ability: Ability }>;
  moves: Array<{ move: Move }>;
  sprites: Sprites;
  types: Array<{ type: Type }>;
  base_experience: number;
  flavor_text: string; // New field for flavor text
}
export interface PokemonWithNumberOfWeek {
  id: number;
  name: string;
  weight: number;
  height: number;
  abilities: Array<{ ability: Ability }>;
  moves: Array<{ move: Move }>;
  sprites: Sprites;
  types: Array<{ type: Type }>;
  base_experience: number;
  flavor_text: string; // New field for flavor text
  number_of_week: number;
}
export interface Generation {
   generationName: string;
   listOfPokemons : PokemonListResponse[];
}
export interface News {
  title: string;
  shortDescription: string;
}


// Define an interface for the API list response
export interface PokemonListResponse {
  name: string;
  url: string;
}

// Define an interface for the API overall response structure
export interface PokemonAPIResponse {
  results: PokemonListResponse[];
}

export interface LikedPokemon{
  id: number;
  name: string;
}

export default class Config {
  static apiUrl = import.meta.env.VITE_API_URL;
}

// @ts-ignore
import { initializeApp } from 'firebase/app';
// @ts-ignore
import { getFirestore } from 'firebase/firestore';


const firebaseConfig = {
  apiKey: 'AIzaSyBePaEAMkF-xnhL8WtM_IvcmjjmEJUfjaw',
  authDomain: 'pokedex-27855.firebaseapp.com',
  projectId: 'pokedex-27855',
  storageBucket: 'pokedex-27855.appspot.com',
  messagingSenderId: '424295983996',
  appId: '1:424295983996:web:857a9754a98a09f92012f9'
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

export{
    db
}

import { defineStore } from 'pinia';
import { ref } from 'vue';
import { db } from '@/firebase';
import { collection, doc, getDocs, addDoc, deleteDoc, query, where } from 'firebase/firestore'; 

export const useQuizStore = defineStore('quiz', () => {
  const questions = ref([
    {
      text: 'Jaký je první Pokémon v Pokédexu?',
      options: ['Bulbasaur', 'Charmander', 'Squirtle', 'Pikachu'],
      correctAnswer: 'Bulbasaur'
    },
    {
      text: 'Který typ je silný proti vodnímu typu?',
      options: ['Ohnivý', 'Travní', 'Létající', 'Broučí'],
      correctAnswer: 'Travní'
    },
    {
      text: 'Jaký je hlavní cíl hry Pokémon?',
      options: ['Chytit je všechny', 'Porazit všechny trenéry', 'Sesbírat odznaky', 'Vyhrát Ligu'],
      correctAnswer: 'Chytit je všechny'
    }
  ]);
  async function saveQuizToFB(resaultOfQuiz: number, userName: string) {
    try {
      const docRef = await addDoc(collection(db, 'quiz'), {
        resault: resaultOfQuiz,
        user: userName
      });
      console.log("Document written with ID: ", docRef.id);
    } catch (error) {
      console.error("Error adding document: ", error);
    }
    console.log("FB written");
  }

  return {
    questions,saveQuizToFB
  };
});

import { defineStore } from "pinia";
import { usePokemonStore } from '@/stores/pokemons';
import { api } from "@/api";
import { Pokemon, PokemonWithNumberOfWeek } from '@/types';
 
export const usePokemonOfTheWeekStore = defineStore("pokemonOfTheWeek", () => {
    const pokemonStore = usePokemonStore();
    const localStorageKey = 'pokemonOfTheWeek';
    // Vypočítá aktuální číslo týdne v roce
    async function getWeekNumberOfTheYear(): Promise<number> {
        const currentDate = new Date();
        const startOfYear = new Date(currentDate.getFullYear(), 0, 1);
        const pastDaysOfYear = (currentDate.getTime() - startOfYear.getTime()) / 86400000;
        return Math.ceil((pastDaysOfYear + startOfYear.getDay() + 1) / 7) - 1;
    }
 
    // Generuje náhodného Pokémona pro týden
    async function generateRandomPokemon(): Promise<PokemonWithNumberOfWeek> {
        try {
            const weekNumber = await getWeekNumberOfTheYear();
            const randomNumberOfPokemon = Math.floor(Math.random() * 1000) + 1;
 
            const randomFetchedPokemon = await fetchRandomPokemon(randomNumberOfPokemon, weekNumber);
 
            savePokemonToLocal(randomFetchedPokemon);
 
            return randomFetchedPokemon;
        } catch (error) {
            console.error('Error generating random Pokemon:', error);
            throw error;
        }
    }
 
    // Načte nebo vygeneruje Pokémona týdne
    async function loadPokemonOfTheWeek(): Promise<Pokemon | null> {
        const [loaded, pokemonData] = loadPokemonFromLocalStorage();
        const currentWeekNumber = await getWeekNumberOfTheYear();
        if (loaded && pokemonData && pokemonData.number_of_week === currentWeekNumber) {
            // Transformuje PokemonWithNumberOfWeek na Pokemon typ
            const pokemon: Pokemon = {
                id: pokemonData.id,
                name: pokemonData.name,
                weight: pokemonData.weight,
                height: pokemonData.height,
                abilities: pokemonData.abilities,
                moves: pokemonData.moves,
                sprites: pokemonData.sprites,
                types: pokemonData.types,
                base_experience: pokemonData.base_experience,
                flavor_text: pokemonData.flavor_text
            };
            return pokemon;
        } else {
            return generateNewPokemonWhenNotLoaded();
        }
    }
 
    // Generuje nového Pokémona, když není načten z local storage
    async function generateNewPokemonWhenNotLoaded(): Promise<Pokemon | null> {
        try {
            const newPokemon = await generateRandomPokemon();
            if (newPokemon) {
                console.log("Generated new Pokemon:", newPokemon);
                return newPokemon;
            }
            return null;
        } catch (error) {
            console.error('Error generating or loading Pokemon:', error);
            return null;
        }
    }
 
    // Uloží Pokémona do local storage
    function savePokemonToLocal(pokemon: PokemonWithNumberOfWeek): void {
        try {
            const pokemonJson = JSON.stringify(pokemon);
            localStorage.setItem(localStorageKey, pokemonJson);
            console.log(`Pokemon saved to localStorage`);
        } catch (error) {
            console.error('Error saving Pokemon to localStorage:', error);
        }
    }
 
    // Získá náhodného Pokémona z API
    async function fetchRandomPokemon(randomNumberOfPokemon: number, numberOfWeek: number): Promise<PokemonWithNumberOfWeek> {
        try {
            const response = await api.get(`/pokemon/${randomNumberOfPokemon}`);
            const speciesResponse = await api.get(response.data.species.url);
            const flavorTextEntry = speciesResponse.data.flavor_text_entries.find((entry: { language: { name: string; }; }) => entry.language.name === "en");
 
            const pokemon: PokemonWithNumberOfWeek = {
                id: response.data.id,
                name: response.data.name,
                weight: response.data.weight,
                height: response.data.height,
                abilities: response.data.abilities.map((ability: { ability: any; }) => ({ ability: ability.ability })),
                moves: response.data.moves.map((move: { move: any; }) => ({ move: move.move })),
                sprites: response.data.sprites,
                types: response.data.types.map((type: { type: any; }) => ({ type: type.type })),
                base_experience: response.data.base_experience,
                flavor_text: flavorTextEntry ? flavorTextEntry.flavor_text.replace(/\n|\f/g, ' ') : "",
                number_of_week: numberOfWeek
            };
 
            console.log("Fetched random Pokemon:", pokemon);
 
            return pokemon;
        } catch (error) {
            console.error("Error fetching random Pokemon:", error);
            throw error;
        }
    }
 
    // Načte Pokémona z local storage
    function loadPokemonFromLocalStorage(): [boolean, PokemonWithNumberOfWeek | null] {
        const pokemonJson = localStorage.getItem(localStorageKey);
        let loaded = false;
        let pokemonData: PokemonWithNumberOfWeek | null = null;
 
        try {
            if (pokemonJson) {
                pokemonData = JSON.parse(pokemonJson) as PokemonWithNumberOfWeek;
                console.log('Loaded Pokemon from local storage:', pokemonData);
                loaded = true;
            } else {
                console.log('No Pokemon loaded from local storage.');
            }
        } catch (error) {
            loaded = false;
            console.error('Error parsing Pokemon data:', error);
        }
 
        return [loaded, pokemonData];
    }
 
    // Vystavuje funkci loadPokemonOfTheWeek pro použití v komponentách
    return {
        loadPokemonOfTheWeek
    };
});
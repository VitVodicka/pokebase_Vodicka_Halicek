import { defineStore } from "pinia";
import { ref } from 'vue';
import { News } from "@/types";

export const useNewsStore = defineStore("news", () => {
  const newsList = ref<News[]>([]);

  const initialNews: News[] = [
    { title: "New Pokémon Discovery: Researchers uncover a rare species in the depths of Johto's ancient ruins.", shortDescription: "Researchers have uncovered a rare and ancient Pokémon species in the ruins of Johto, sparking excitement among trainers and scientists alike." },
    { title: "Pokémon League Update: Trainers prepare for the upcoming Indigo Plateau Championship.", shortDescription: "Trainers are gearing up for the highly anticipated Indigo Plateau Championship, where only the best will emerge victorious." },
    { title: "Pokémon Breeding Breakthrough: Scientists unveil a new technique to boost Pokémon abilities through advanced genetic research.", shortDescription: "A new breeding technique has been discovered, promising to significantly boost Pokémon abilities through genetic advancements." },
    { title: "Legendary Pokémon Sighting: Eyewitnesses report seeing a majestic Ho-Oh near Ecruteak City.", shortDescription: "A majestic Ho-Oh has been sighted near Ecruteak City, drawing trainers from all over to catch a glimpse." },
    { title: "Pokémon Go Community Day: Trainers eagerly await Niantic's announcement of featured Pokémon and special bonuses for this month's event.", shortDescription: "This month's Pokémon Go Community Day promises exciting featured Pokémon and bonuses, eagerly awaited by trainers." },
    { title: "Mega Evolution Alert: A newly discovered Mega Stone grants unprecedented power to select Pokémon.", shortDescription: "A new Mega Stone has been discovered, granting unprecedented power to select Pokémon and altering battle strategies." },
    { title: "Pokémon Mystery Dungeon: Rumors of a hidden dungeon filled with rare items and Pokémon spread among adventurers.", shortDescription: "Rumors are spreading about a hidden dungeon filled with rare items and Pokémon, enticing adventurers to explore." },
    { title: "Shiny Pokémon Hunt: Trainers report an increased appearance of Shiny Pokémon in the wild.", shortDescription: "There has been an increased appearance of Shiny Pokémon in the wild, sparking a new wave of hunts among trainers." },
    { title: "Pokémon Trading Card Game: New expansion set to introduce powerful new cards and strategies.", shortDescription: "A new expansion for the Pokémon Trading Card Game is set to introduce powerful new cards and innovative strategies." },
    { title: "Pokémon Home Update: New features added to improve Pokémon storage and transfer capabilities.", shortDescription: "The latest Pokémon Home update brings new features to enhance storage and transfer capabilities for trainers." },
  ];

  newsList.value = initialNews;

  function fetchNews(): News[] {
    return newsList.value;
  }

  return {
    fetchNews
  };
});

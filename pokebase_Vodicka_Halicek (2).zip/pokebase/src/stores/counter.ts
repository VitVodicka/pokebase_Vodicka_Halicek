import { defineStore } from "pinia"
import { ref } from "vue"

export const useCounterStore = defineStore('counter', () => {
  const viewedPokemonIds = ref<number[]>([])

  function viewPokemon(id: number) {
    viewedPokemonIds.value.push(id)
  }

  function wasPokemonViewed(id: number) {
    return viewedPokemonIds.value.includes(id)
  }

  function getTotalPokemonViews(id: number) {
    return viewedPokemonIds.value.filter(pokemonId => pokemonId === id).length
  }

  return { viewPokemon, wasPokemonViewed, getTotalPokemonViews }
})

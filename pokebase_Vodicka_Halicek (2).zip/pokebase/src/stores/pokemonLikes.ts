import { defineStore } from "pinia";
import { reactive } from 'vue';
import { db } from '@/firebase';
// @ts-ignore
import { collection, doc, getDocs, addDoc, deleteDoc, query, where } from 'firebase/firestore';
import { LikedPokemon } from "@/types";

export const usePokemonLikesStore = defineStore("pokemonLikes", () => {
  const storeStateLikedPokemons = reactive({
    likedPokemons: [] as LikedPokemon[]
  });

  async function deletePokemonFromFBByIdAndName(idInput: number, nameInput: string) {
    try {
      const pokemonQuery = query(
        collection(db, 'favouritePokemons'),
        where('id', '==', idInput),
        where('name', '==', nameInput)
      );

      const querySnapshot = await getDocs(pokemonQuery);
      if (querySnapshot.empty) {
        console.log(`No documents found with id ${idInput} and name ${nameInput}`);
        return;
      }

      for (const doc of querySnapshot.docs) {
        try {
          await deleteDoc(doc.ref);
          console.log(`Document with id ${idInput} and name ${nameInput} successfully deleted`);
        } catch (error) {
          console.error(`Error deleting document with id ${idInput} and name ${nameInput}: `, error);
        }
      }
    } catch (error) {
      console.error(`Error querying documents with id ${idInput} and name ${nameInput}: `, error);
    }
  }

  async function loadFavouritePokemonsFromFB() {
    try {
      const querySnapshot = await getDocs(collection(db, 'favouritePokemons'));
      let likedPokemonsFromFB: LikedPokemon[] = [];
      querySnapshot.forEach((doc: { data: () => any; id: any; }) => {
        const data = doc.data();
        if (data.id !== undefined && data.name !== undefined) {
          likedPokemonsFromFB.push({ id: data.id, name: data.name });
        } else {
          console.log("Document missing some field ", doc.id, data);
        }
      });
      storeStateLikedPokemons.likedPokemons = likedPokemonsFromFB;
    } catch (error) {
      console.error("Error loading favourite Pokemons from Firestore: ", error);
    }
  }

  async function saveFavouritePokemonToFB(idInput: number, nameInput: string) {
    try {
      const docRef = await addDoc(collection(db, 'favouritePokemons'), {
        id: idInput,
        name: nameInput
      });
      console.log("Document written with ID: ", docRef.id);
    } catch (error) {
      console.error("Error adding document: ", error);
    }
    console.log("FB written");
  }

  return {
    deletePokemonFromFBByIdAndName,
    loadFavouritePokemonsFromFB,
    saveFavouritePokemonToFB,
    storeStateLikedPokemons
  };
});

// Import necessary libraries and types
import { api } from "@/api";                         // Import a pre-configured Axios instance for API calls
import type { Pokemon as PokemonType } from "@/model/Pokemon";      // Import Pokemon type definition
import { defineStore } from "pinia";                 // Import Pinia's defineStore function to create a store
import { computed, reactive, ref } from "vue";       // Import Vue composition API functions for reactivity
import { useRouter } from "vue-router";              // Import useRouter for routing control
import {  PokemonListResponse, Generation } from "@/types"; // Import custom types for API responses
import Pokemon from "@/router/pages/Pokemon.vue";
import { AxiosResponse } from 'axios';
import { db } from '@/firebase';
import { usePokemonLikesStore } from '@/stores/pokemonLikes';

// Define the store using Pinia's defineStore function
export const usePokemonStore = defineStore("pokemons", () => {
  // Utilize Vue Router for navigation and redirects
  const router = useRouter();

  // Define reactive state variables
  let pokemons = reactive<PokemonType[]>([]); // Reactive array to store Pokemon data
  const isLoading = ref(false);             // Reactive reference to track loading state
  const isAdding = ref(false);              // Reactive reference to track if a new Pokemon is being added
  const error = ref<string | null>(null);   // Reactive reference to store any error messages
  const favoritePokemons = ref<number[]>([]); // Reactive array to store IDs of favorite Pokemon
  const currentPage = ref(1);               // Reactive reference to track the current page of Pokemon list
  const pageSize = 48;                      // Number of Pokemon to fetch per page
  const generations = ref([String])
  let generationName="";
  const listOfGenerations: Generation[] = [];
  let startingLastGenerationIndex=1;
  const pokemonLikesStore = usePokemonLikesStore();
  let canToggle = true;

  const toggleFavoriteWithDelay = (pokemonId: number, pokemonName: string) => {
    if (canToggle) {
      toggleFavorite(pokemonId, pokemonName);
      canToggle = false;
      setTimeout(() => {
        canToggle = true;
      }, 1000); // Omezení na jedno kliknutí za sekundu
    }
  };


  // Computed property to calculate the total number of Pokemon
  const totalPokemons = computed<number>(() => pokemons.length);

  // Asynchronous function to fetch Pokemons from the API
  async function fetchPokemons() {
    isLoading.value = true;
    error.value = null;

    try {
      //if user chooses pokdex with pokemon generation
      if (generationName == "") {
        const offset = (currentPage.value - 1) * pageSize;
        const response = await api.get(`/pokemon?limit=${pageSize}&offset=${offset}`);
        const pokemonDetailsPromises = response.data.results.map((pokemon: PokemonListResponse) => {
          return fetchPokemonsDetails(pokemon);
        });
        //fetches pokemons
        const fetchedPokemons = (await Promise.all(pokemonDetailsPromises)).filter(Boolean) as PokemonType[];
        pokemons.splice(0, pokemons.length, ...fetchedPokemons);
      } else {
        let generationsWithNames = listOfGenerations.find(gen => gen.generationName == generationName);
        if (generationsWithNames) {
          const offset = (currentPage.value - 1) * pageSize;
          const generationPokemons = generationsWithNames.listOfPokemons.slice(offset, offset + pageSize);
          const pokemonDetailsPromises = generationPokemons.map((pokemon: PokemonListResponse) => {
            return fetchPokemonsDetails(pokemon, pokemon.url.replace('pokemon-species', 'pokemon'));
          });
          //fetches pokemons
          const fetchedPokemons = (await Promise.all(pokemonDetailsPromises)).filter(Boolean) as PokemonType[];
          pokemons.splice(0, pokemons.length, ...fetchedPokemons);
        }
      }
    } catch (e) {
      console.error("Failed to load pokemons:", e);
      error.value = "Cannot download pokemons. 😢";
    } finally {
      isLoading.value = false;
    }
  }

  async function fetchPokemonsDetails(pokemon: PokemonListResponse, urlOverride?: string): Promise<PokemonType | null> {
    try {
      let detailResponse: AxiosResponse;
      if (urlOverride) {
        detailResponse = await api.get(urlOverride);
      } else {
        detailResponse = await api.get(pokemon.url);
      }

      if (!detailResponse || !detailResponse.data || !detailResponse.data.species || !detailResponse.data.species.url) {
        throw new Error("Invalid detail response");
      }

      const speciesResponse = await api.get(detailResponse.data.species.url);
      const flavorTextEntry = speciesResponse.data.flavor_text_entries.find(
        (entry: { language: { name: string; }; }) => entry.language.name === "en"
      );

      const pokemonData = {
        ...detailResponse.data,
        flavor_text: flavorTextEntry ? flavorTextEntry.flavor_text : ''
      } as PokemonType;

      return pokemonData;
    } catch (error) {
      console.error("Failed to fetch pokemon details:", error);
      return null;
    }
  }



  // Asynchronous function to add a new Pokemon to the store and API
  async function addPokemon(pokemon: PokemonType) {
    isAdding.value = true;
    error.value = null;

    try {
      const response = await api.post('/pokemon', pokemon);
      pokemons.push(response.data);
      router.push({ name: 'pokemon', params: { id: response.data.id } });
    } catch (e: any) {
      console.error(e.message, e.response?.data);
      error.value = 'Cannot save the new pokemon. ' + (e.response?.data?.message ?? '');
    } finally {
      isAdding.value = false;
    }
  }

  // Asynchronous function to fetch a specific Pokemon by ID or name
  async function fetchPokemon(pokemonIdOrName: number | string) {
    try {
      const response = await api.get(`/pokemon/${pokemonIdOrName}`);
      const pokemon = response.data;
      const existingIndex = pokemons.findIndex((p) => p.id === pokemon.id);
      if (existingIndex !== -1) {
        pokemons[existingIndex] = pokemon;
      } else {
        pokemons.push(pokemon);
      }
    } catch (e: any) {
      console.error(e.message, e.response?.data);
      router.replace({ name: "notfound" });
    }
  }

  // Function to retrieve a Pokemon by ID from the local store
  function getPokemonById(pokemonId: number): PokemonType | undefined {
    return pokemons.find((p) => p.id === pokemonId);
  }

  // Function to toggle the favorite status of a Pokemon
  function toggleFavorite(pokemonId: number, pokemonName:string) {
    const index = favoritePokemons.value.indexOf(pokemonId);
    if (index !== -1) {
      pokemonLikesStore.deletePokemonFromFBByIdAndName(pokemonId, pokemonName);
      console.log(`Pokémon with ID ${pokemonId} and Name ${pokemonName} is currently favorited. Removing from favorites.`);
      favoritePokemons.value.splice(index, 1);
    } else {
      pokemonLikesStore.saveFavouritePokemonToFB(pokemonId,pokemonName);
      console.log(`Pokémon with ID ${pokemonId} and Name ${pokemonName} is currently not favorited. Adding to favorites.`);
      favoritePokemons.value.push(pokemonId);
    }
  }


  async function getGenerations(): Promise<Generation[]> {

    if(listOfGenerations.length===0){
      for (let i = 1; i < 10; i++) {
        try {
          const response = await api.get(`/generation/${i}`);
          const generationPokemonName = response.data.main_region.name;
          const pokemonList: PokemonListResponse[] = response.data.pokemon_species;

          const generation: Generation = {
            generationName: generationPokemonName,
            listOfPokemons: pokemonList
          };

          listOfGenerations.push(generation);
        } catch (error) {
          console.error('Error fetching generations:', error);
        }
      }
    }

    return listOfGenerations;
  }

  function setGenerationName(name:string){
    generationName=name;
  }
  function getGenerationName():string{
    return generationName;
  }


  // Function to check if a Pokemon is marked as favorite
  function isFavorite(pokemonId: number) {
    return favoritePokemons.value.includes(pokemonId);
  }

  // Function to navigate to the next page of Pokemon list
  function goToNextPage() {
    currentPage.value++;
    console.log("Updated Current Page to:", currentPage.value); // Log the new page number
    fetchPokemons();
  }

  // Function to navigate to the previous page of Pokemon list
  function goToPreviousPage() {
    if (currentPage.value > 1) {
      currentPage.value--;
      console.log("Updated Current Page to:", currentPage.value); // Log the new page number
      fetchPokemons();
    }
  }
  // Return all the reactive states, computed properties, and functions
  return {
    pokemons,
    isLoading,
    isAdding,
    error,
    totalPokemons,
    currentPage,
    pageSize,
    fetchPokemons,
    addPokemon,
    fetchPokemon,
    getPokemonById,
    toggleFavorite,
    isFavorite,
    goToNextPage,
    goToPreviousPage,
    getGenerations,
    setGenerationName,
    getGenerationName,
    toggleFavoriteWithDelay

  };
});

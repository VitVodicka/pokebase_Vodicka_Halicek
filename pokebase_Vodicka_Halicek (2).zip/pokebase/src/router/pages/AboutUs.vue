<template>
  <div class="about-us-page">
    <PokemonTitle></PokemonTitle>

    <h1>About Us</h1>

    <v-card class="mb-4">
      <v-card-title>Our Mission</v-card-title>
      <v-card-text>
        <p>At PokéBase, we are dedicated to providing the most comprehensive and user-friendly Pokémon database for trainers and enthusiasts worldwide.</p>
      </v-card-text>
    </v-card>

    <v-card class="mb-4">
      <v-card-title>Who We Are</v-card-title>
      <v-card-text>
        <p>We are a team of passionate Pokémon fans and developers, committed to creating the best possible resource for the Pokémon community.</p>
      </v-card-text>
    </v-card>

    <v-card class="mb-4">
      <v-card-title>Our Features</v-card-title>
      <v-card-text>
        <ul>
          <li>Comprehensive Pokédex with detailed information on all Pokémon</li>
          <li>Advanced search and filtering options</li>
          <li>Favorite Pokémon tracking</li>
          <li>Regular updates with the latest Pokémon data</li>
        </ul>
      </v-card-text>
    </v-card>

    <v-card>
      <v-card-title>Contact Us</v-card-title>
      <v-card-text>
        <p>Have questions or suggestions? Reach out to us at: <a href="mailto:contact@pokebase.com">contact@pokebase.com</a></p>
      </v-card-text>
    </v-card>
  </div>
</template>

<script setup lang="ts">
</script>

<style scoped>
.about-us-page {
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
}

h1 {
  text-align: center;
  margin-bottom: 20px;
}

.v-card {
  margin-bottom: 20px;
}
</style>

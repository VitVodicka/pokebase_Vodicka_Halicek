<template>
  <!-- Main component structure -->
  <PokemonTitle></PokemonTitle>
  <h1>{{ weekNumber }}</h1>
  <div class="pokemon-news-section">
  <!-- Pokemon of the week section -->
  <div class="pokemon-section">
  <div class="pokemon-card" :class="{ 'pokemon-card--loading': loading }">
  <template v-if="pokemon">
  <h1 class="pokemon-of-the-week">Pokemon of the week</h1>
  <div class="pokemon-info-section">
  <!-- Pokemon details display -->
  <h2 class="pokemon-name">{{ pokemon.name }}</h2>
  <img :src="pokemon.sprites.front_default" alt="Pokemon Image" height="250px" width="250px" />
  <div class="pokemon-details">
  <p><strong>Weight:</strong> {{ pokemon.weight }} kg</p>
  <p><strong>Height:</strong> {{ pokemon.height }}</p>
  <p><strong>Base Experience:</strong> {{ pokemon.base_experience }}</p>
  </div>
  <!-- Pokemon types display -->
  <div class="pokemon-types">
  <h3>Types:</h3>
  <div class="type-chips">
  <span v-for="type in pokemon.types" :key="type.type.name" class="type-chip">
                    {{ type.type.name }}
  </span>
  </div>
  </div>
  <!-- Pokemon abilities display -->
  <div class="pokemon-abilities">
  <h3>Abilities:</h3>
  <div class="ability-chips">
  <span v-for="ability in pokemon.abilities" :key="ability.ability.name" class="ability-chip">
                    {{ ability.ability.name }}
  </span>
  </div>
  </div>
  <!-- Pokemon flavor text -->
  <div class="pokemon-flavor-text">
  <h3>Flavor Text:</h3>
  <p>{{ pokemon.flavor_text }}</p>
  </div>
  </div>
  </template>
  </div>
  </div>
  <!-- News section -->
  <div class="news-section">
  <h1 class="news-header">Pokémon novinky</h1>
  <v-list class="news-list">
  <!-- News items list -->
  <v-list-item
            v-for="newsItem in localNewsList"
            :key="newsItem.title"
            class="news-item">
  <v-list-item-content>
  <v-list-item-title class="news-title">{{ newsItem.title }}</v-list-item-title>
  <v-list-item-subtitle class="news-subtitle">{{ newsItem.shortDescription }}</v-list-item-subtitle>
  </v-list-item-content>
  </v-list-item>
  </v-list>
  </div>
  </div>
  </template>
   
  <script lang="ts" setup>
  import { onMounted, ref } from 'vue';
  import PokemonTitle from '@/components/PokemonTitle.vue';
  import { useNewsStore } from '@/stores/news';
  import { usePokemonOfTheWeekStore } from '@/stores/pokemonOfTheWeek';
  import loading from "@/components/Loading.vue";
  import {News, Pokemon} from "@/types";
   
  // Initialize stores
  const newsStore = useNewsStore();
  const pokemonOfTheWeekStore = usePokemonOfTheWeekStore();
   
  // Reactive references
  const pokemon = ref<Pokemon | null>(null);
  const weekNumber = ref<number | null>(null);
  const localNewsList = ref<News[]>([]);
   
  // Lifecycle hook
  onMounted(async () => {
    // Fetch news
    newsStore.fetchNews();
    localNewsList.value = newsStore.fetchNews();
   
    // Load Pokemon of the week
    try {
      pokemon.value = await pokemonOfTheWeekStore.loadPokemonOfTheWeek();
    } catch (error) {
      console.error('Error loading Pokemon of the week:', error);
    }
  });
  </script>
   
  <style scoped>
  /* Styles for the component layout */
  .pokemon-news-section {
    display: flex;
    margin: 60px 20px;
    gap: 40px;
  }
   
  .pokemon-section {
    flex-basis: 30%;
  }
   
  /* Styles for the Pokemon card */
  .pokemon-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
    border: 1px solid #ccc;
    background: #ffffff;
    border-radius: 8px;
    padding: 20px;
  }
   
  /* Styles for Pokemon information */
  .pokemon-of-the-week {
    text-align: center;
    margin-bottom: 20px;
  }
   
  .pokemon-info-section {
    text-align: center;
    color: #333;
  }
   
  .pokemon-name {
    color: #FF6347;
    margin-bottom: 20px;
  }
   
  /* Styles for type and ability chips */
  .type-chips, .ability-chips {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    justify-content: center;
    margin-bottom: 20px;
  }
   
  .type-chip, .ability-chip {
    background-color: #0F3460;
    color: #E5E5E5;
    border-radius: 20px;
    padding: 5px 10px;
    font-size: 14px;
  }
   
  /* Styles for flavor text */
  .pokemon-flavor-text p {
    background-color: #16213E;
    color: #FFFFFF;
    padding: 10px;
    border-radius: 8px;
    font-size: 14px;
  }
   
  /* Styles for news section */
  .news-section {
    flex: 1;
    background-color: #f8f8f8;
    border-radius: 8px;
    padding: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
  }
   
  .news-header {
    text-align: left;
    margin-bottom: 20px;
    color: #0F3460;
  }
   
  /* Styles for news items */
  .news-item {
    border-bottom: 1px solid #ddd;
    padding: 10px;
    transition: background-color 0.3s;
  }
   
  .news-item:hover {
    background-color: #e0f7fa;
  }
   
  .news-title {
    font-size: 18px;
    font-weight: bold;
    color: #0F3460;
  }
   
  .news-subtitle {
    font-size: 14px;
    color: #757575;
  }
   
  .news-item:last-child {
    border-bottom: none;
  }
  </style>
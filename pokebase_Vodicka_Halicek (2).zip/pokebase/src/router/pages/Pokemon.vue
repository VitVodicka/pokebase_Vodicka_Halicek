<template>
  <PokemonTitle></PokemonTitle>
  <div class="pokemon-details-page">
    <div class="pokemon-card" :class="{ 'pokemon-card--loading': loading }">
      <template v-if="pokemon">
        <div class="pokemon-image-section">
          <img :src="pokemon.sprites.front_default" alt="Pokemon Image" />
        </div>
        <div class="pokemon-info-section">
          <h2 class="pokemon-name">{{ pokemon.name }}</h2>
          <div class="pokemon-details">
            <p><strong>ID:</strong> {{ pokemon.id }}</p>
            <p><strong>Weight:</strong> {{ pokemon.weight }} kg</p>
            <p><strong>Height:</strong> {{ pokemon.height }}</p>
            <p><strong>Base Experience:</strong> {{ pokemon.base_experience }}</p>
          </div>
          <div class="pokemon-types">
            <h3>Types:</h3>
            <div class="type-chips">
              <span v-for="type in pokemon.types" :key="type.type.name" class="type-chip">
                {{ type.type.name }}
              </span>
            </div>
          </div>
          <div class="pokemon-abilities">
            <h3>Abilities:</h3>
            <div class="ability-chips">
              <span v-for="ability in pokemon.abilities" :key="ability.ability.name" class="ability-chip">
                {{ ability.ability.name }}
              </span>
            </div>
          </div>
          <div class="pokemon-flavor-text">
            <h3>Flavor Text:</h3>
            <p>{{ pokemon.flavor_text }}</p>
          </div>
          <div class="pokemon-actions">
            <button class="favorite-button" @click="toggleFavoriteWithDelay" :class="{ 'favorite-button--active': isFavorite }">
              <i class="fas fa-star"></i> {{ isFavorite ? 'Unfavorite' : 'Favorite' }}
            </button>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>



<script setup lang="ts">
import { computed, ref, onMounted } from 'vue';
import { usePokemonStore } from '@/stores/pokemons';
import { Pokemon } from '@/types';
import { api } from '@/api';
import PokemonTitle from '@/components/PokemonTitle.vue';



const props = defineProps<{ id: string }>();

const pokemonStore = usePokemonStore();


const loading = ref(false);
const pokemon = ref<Pokemon | null>(null);

const toggleFavoriteWithDelay = () => {
  if(pokemon.value){
  pokemonStore.toggleFavoriteWithDelay(pokemon.value.id,pokemon.value.name);
  }
};



const isFavorite = computed(() => {
  if (pokemon.value) {
    return pokemonStore.isFavorite(pokemon.value.id);
  }
  return false;
});

onMounted(() => {
  searchPokemon(props.id);
});

const searchPokemon = async (id: string) => {
  loading.value = true;
  try {
    const response = await api.get(`/pokemon/${id}`);
    const speciesResponse = await api.get(response.data.species.url);
    const flavorTextEntry = speciesResponse.data.flavor_text_entries.find((entry: { language: { name: string; }; }) => entry.language.name === "en");

    pokemon.value = {
      ...response.data,
      flavor_text: flavorTextEntry ? flavorTextEntry.flavor_text.replace(/\n|\f/g, ' ') : ""
    };
  } catch (e) {
    console.error(`Pokemon with ID "${id}" not found.`);
  } finally {
    loading.value = false;
  }
};
</script>

<style scoped>
.pokemon-details-page {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  padding: 20px;
  background-color: #E5E5E5; /* Light grey background to help with contrast */
}

.pokemon-card {
  display: flex;
  flex-direction: row; /* Align items horizontally */
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2); /* Soft shadow for 3D effect */
  border: 1px solid #ccc; /* Light grey border for subtle separation */
  width: 90%;
  max-width: 800px;
  background: #ffffff; /* Ensure card is solid white */
  border-radius: 8px;
  overflow: hidden;
}

.pokemon-image-section {
  flex: 1 1 30%; /* Flex basis at 30% of the parent */
  border-right: 1px solid #ddd; /* Separator between image and text */
}

.pokemon-image-section img {
  width: 100%;
  height: auto;
  padding: 20px;
}

.pokemon-info-section {
  flex: 1 1 70%; /* Flex basis at 70% of the parent */
  padding: 20px;
  color: #333; /* Darker text for better readability */
}

.pokemon-name {
  text-align: center;
  color: #FF6347; /* A vibrant color for the name */
  margin-bottom: 20px;
}

.type-chips, .ability-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  justify-content: start;
}

.type-chip, .ability-chip {
  background-color: #0F3460;
  color: #E5E5E5;
  border-radius: 20px;
  padding: 5px 10px;
  font-size: 14px;
  margin: 2px;
}

.pokemon-flavor-text p {
  background-color: #16213E;
  color: #FFFFFF;
  padding: 10px;
  border-radius: 8px;
  font-size: 14px;
  margin-top: 10px;
}

.favorite-button {
  display: block;
  width: 100%;
  text-align: center;
  margin-top: 20px;
  padding: 10px 20px;
  font-size: 16px;
  background-color: #0F3460;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.favorite-button--active {
  background-color: #E94560;
}
</style>


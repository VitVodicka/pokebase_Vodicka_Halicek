<template>
    <PokemonTitle></PokemonTitle>
    <v-container>
    <v-row justify="center">
    <v-col cols="12" md="8">
    <h1>Pokemon Quiz</h1>
    <!-- Quiz questions -->
    <v-card class="pa-4" v-for="(question, index) in questions" :key="index" v-show="index === currentQuestionIndex">
    <v-card-title>{{ question.text }}</v-card-title>
    <v-card-text>
    <!-- Radio button group for answer options -->
    <v-radio-group v-model="selectedAnswers[index]" :name="`question-${index}`">
    <v-radio v-for="option in question.options" :key="option" :label="option" :value="option"></v-radio>
    </v-radio-group>
    </v-card-text>
    </v-card>
    <!-- Navigation buttons -->
    <v-row class="my-4" justify="center">
    <v-btn @click="prevQuestion" :disabled="currentQuestionIndex === 0" class="mx-2">
                previous
    </v-btn>
    <v-btn v-if="currentQuestionIndex < questions.length - 1" @click="nextQuestion" class="mx-2">
                next
    </v-btn>
    <v-btn v-else @click="checkAnswers" :disabled="result !== null" class="mx-2">
                Send answers
    </v-btn>
    </v-row>
    <!-- Result display and submission -->
    <v-alert v-if="result !== null" type="success" class="result-alert">
    <h2>Result: {{ result }}/{{ questions.length }}</h2>
    <v-text-field v-model="username" label="Enter your name" class="my-4"></v-text-field>
    <v-btn @click="submitResult" :disabled="!username" class="mx-2">Share your result</v-btn>
    </v-alert>
    </v-col>
    </v-row>
    </v-container>
    </template>
     
    <script setup lang="ts">
    import { ref } from 'vue';
    import { useQuizStore } from '@/stores/quizes';
    import PokemonTitle from '@/components/PokemonTitle.vue';
     
    // Initialize quiz store and get questions
    const quizStore = useQuizStore();
    const questions = quizStore.questions;
     
    // Reactive references
    const currentQuestionIndex = ref(0);
    const selectedAnswers = ref(Array(questions.length).fill(null));
    const result = ref<number | null>(null);
    const username = ref('');
     
    // Navigation functions
    const nextQuestion = () => {
      if (currentQuestionIndex.value < questions.length - 1) {
        currentQuestionIndex.value++;
      }
    };
     
    const prevQuestion = () => {
      if (currentQuestionIndex.value > 0) {
        currentQuestionIndex.value--;
      }
    };
     
    // Check answers and calculate result
    const checkAnswers = () => {
      let correctCount = 0;
      questions.forEach((question, index) => {
        if (selectedAnswers.value[index] === question.correctAnswer) {
          correctCount++;
        }
      });
      result.value = correctCount;
    };
     
    // Submit result to Firebase
    const submitResult = async () => {
      if (!username.value || result.value === null) return;
      await quizStore.saveQuizToFB(result.value, username.value);
    };
    </script>
     
    <style scoped>
    .quiz-container {
      max-width: 600px;
      margin: 0 auto;
      text-align: center;
    }
    .result-alert {
      background-color: #212863;
    }
    </style>
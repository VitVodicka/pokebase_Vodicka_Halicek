<template>
  <PokemonTitle></PokemonTitle>
  
  <div>
    

    <v-container class="my-5">
      <v-row>
        <v-col cols="12">
          <h1 class="text-h2 text-center mb-5">Pokémon Generations</h1>
        </v-col>
      </v-row>
      <v-row justify="center">
        <v-col
          v-for="generation in generations"
          :key="generation.generationName"
          cols="12" sm="6" md="4" lg="3">
          <v-card
            @click="goToPokedex(generation.generationName)"
            class="ma-3 elevation-12"
            hoverable>
            <v-card-title class="headline text-center">{{ generation.generationName }}</v-card-title>
          </v-card>
        </v-col>
      </v-row>
      </v-container>
      </div>
</template>

<script setup lang="ts">
import PokemonTitle from '@/components/PokemonTitle.vue';
import { onMounted, ref } from 'vue';
import { usePokemonStore } from '@/stores/pokemons';
import { Generation } from '@/types';
import { useRouter } from 'vue-router';


const router = useRouter();
const pokemonsStore = usePokemonStore();
const generations = ref<Generation[]>([]);

onMounted(async () => {
    if(generations.value!= null){
    generations.value = await pokemonsStore.getGenerations();}
    pokemonsStore.setGenerationName("");
});

function goToPokedex(generationName: string){
  pokemonsStore.setGenerationName(generationName);
  router.push({ name: 'pokedex' });
}
</script>

<style scoped>
.categories {
  display: flex;
  justify-content: start;
  align-items: stretch;
  margin-top: 20px;
  background-color: lightgray;
}

.v-container {
  padding-bottom: 10vw;
  width: 100%;
  flex: 1;
}

.v-list {
  padding: 16px;
  background-color: darkgrey;
  border-radius: 16px;
  height: 100%;
  flex: 1;
}

.v-list-item {
  margin-bottom: 8px;
  width: 80vw;
  background-color: white;
  flex: 1;
  margin-right: 5vw;
}
</style>

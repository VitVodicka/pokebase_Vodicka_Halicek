<template>
  <PokemonTitle></PokemonTitle>
  <div class="pokedex-page">
    <h1 id="title">{{ PokedexTitleBasedOnGenerationOrDefaultName }}</h1>

    <div class="search-bar">
      <v-text-field v-model="searchQuery" label="Search Pokémon" placeholder="Enter Pokémon name"></v-text-field>
    </div>

    <div v-if="isLoading" class="loading" data-cy="loading-overlay">
      <v-progress-circular indeterminate color="primary"></v-progress-circular>
      <p>Loading Pokémon...</p>
    </div>

    <div v-else class="pokemon-list loaded-content">
      <v-card
        v-for="pokemon in filteredPokemons"
        :key="pokemon.id"
        class="pokemon-card"
        data-cy="pokemon-card"
        @click="openPokemonDetails(pokemon.id)"
      >
        <v-img :src="pokemon.sprites?.front_default" height="200px"></v-img>
        <v-card-title>{{ pokemon.name }}</v-card-title>
        <v-card-text>
          <p>ID: {{ pokemon.id }}</p>
          <p>Weight: {{ pokemon.weight }}</p>
          <p>Height: {{ pokemon.height }}</p>
          <div v-if="pokemon.abilities">
            <strong>Abilities:</strong>
            <v-chip v-for="(ability, index) in pokemon.abilities" :key="index" class="ma-1">
              {{ ability.ability.name }}
            </v-chip>
          </div>
        </v-card-text>
        <v-card-actions>
          <v-btn icon @click.stop="toggleFavoriteWithDelay(pokemon.id, pokemon.name)">
            <v-icon :color="isFavorite(pokemon.id) ? 'yellow' : ''">mdi-star</v-icon>
          </v-btn>
        </v-card-actions>
      </v-card>
    </div>

    <div v-if="!isLoading" class="pagination">
      <v-btn icon @click="goToPreviousPage" :disabled="pokemonStore.currentPage === 1">
        <v-icon>mdi-arrow-left</v-icon>
      </v-btn>
      <span>Page {{ pokemonStore.currentPage }}</span>
      <v-btn icon @click="goToNextPage">
        <v-icon>mdi-arrow-right</v-icon>
      </v-btn>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, computed, ref } from 'vue';
import { usePokemonStore } from '@/stores/pokemons';
import { Pokemon } from '@/types';
import { useRouter } from 'vue-router';
import PokemonTitle from '@/components/PokemonTitle.vue';
import { onBeforeUnmount } from 'vue';

const PokedexTitleBasedOnGenerationOrDefaultName = computed(() => {
  return pokemonStore.getGenerationName() ? `Pokédex - Generation ${pokemonStore.getGenerationName()}` : 'Pokédex';
});

const props = defineProps<{ id: string }>();
const pokemonStore = usePokemonStore();
const router = useRouter();

const isLoading = computed(() => pokemonStore.isLoading);
const pokemons = pokemonStore.pokemons as Pokemon[];
const toggleFavorite = pokemonStore.toggleFavorite;
const isFavorite = pokemonStore.isFavorite;
const currentPage = pokemonStore.currentPage;
const goToNextPage = pokemonStore.goToNextPage;
const goToPreviousPage = pokemonStore.goToPreviousPage;

const searchQuery = ref('');

const toggleFavoriteWithDelay = (pokemonId: number, pokemonName: string) => {
  pokemonStore.toggleFavoriteWithDelay(pokemonId, pokemonName);
};

const filteredPokemons = computed(() => {
  if (searchQuery.value.trim() === '') {
    return pokemons;
  }
  return pokemons.filter((pokemon) =>
    pokemon.name.toLowerCase().includes(searchQuery.value.toLowerCase())
  );
});

onMounted(async () => {
  await pokemonStore.fetchPokemons();
});

onBeforeUnmount(async () => {
  pokemonStore.setGenerationName("");
});

function openPokemonDetails(pokemonId: number) {
  router.push({ name: 'pokemon', params: { id: pokemonId.toString() } });
}
</script>

<style scoped>
.pokedex-page {
  padding: 20px;
}

.search-bar {
  margin-bottom: 20px;
}

.pokemon-list {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  grid-gap: 20px;
}

.pokemon-card {
  transition: transform 0.3s ease-in-out;
  cursor: pointer;
}

.pokemon-card:hover {
  transform: translateY(-5px);
}

.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 20px;
}

.loading {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 200px;
}
</style>

import Homepage from "@/router/pages/Homepage.vue";
import Login from "@/router/pages/Login.vue";
import ListOfItems from "@/router/pages/ListOfItems.vue";
import Pokedex from "@/router/pages/Pokedex.vue";
import Pokemon from "@/router/pages/Pokemon.vue";
import Quiz from "@/router/pages/Quiz.vue";
import AboutUs from "@/router/pages/AboutUs.vue";
import NotFound from "@/router/pages/NotFound.vue";
import { createRouter, createWebHistory, RouteRecordRaw, useRouter } from "vue-router";
import { useAuthStore } from "@/stores/auth";

// type defined for route meta to pass for example page name to NavigationDrawer title (renamed from PageDetails to RouteMeta)
export type RouteMeta = {
  label: string,        // name
  iconClass: string,    // if needed a custom icon
  requiresAuth: boolean // login
};

// underlines input when a bad value type is inserted (previous solution was like const homepage: RouteMeta = {} without this funct)
function getRouteMeta(input: RouteMeta): RouteMeta {
  return input
};

const routes: RouteRecordRaw[] = [
  {
    path: "/",
    component: Homepage,
    name: "homepage",
    meta: getRouteMeta({
      label: "Homepage",
      iconClass: "",
      requiresAuth: false
    })
  },
  {
    path: "/login",
    component: Login,
    name: "login",
    meta: getRouteMeta({
      label: "Login",
      iconClass: "",
      requiresAuth: false
    })
  },
  {
    path: "/list-of-items",
    component: ListOfItems,
    name: "listofitems",
    meta: getRouteMeta({
      label: "List of Items",
      iconClass: "",
      requiresAuth: false
    })
  },
  {
    path: "/pokedex",
    component: Pokedex,
    name: "pokedex",
    meta: getRouteMeta({
      label: "Pokédex",
      iconClass: "",
      requiresAuth: false
    })
  },
  {
    path: "/pokemon/:id",
    component: Pokemon,
    name: "pokemon",
    meta: getRouteMeta({
      label: "Pokémon",
      iconClass: "",
      requiresAuth: false
    }),
    props: true
  },
  {
    path: "/quiz",
    component: Quiz,
    name: "quiz",
    meta: getRouteMeta({
      label: "Quiz",
      iconClass: "",
      //requiresAuth: true
      requiresAuth: false
    }),
    props: true
  },
  {
    path: "/about-us",
    component: AboutUs,
    name: "aboutus",
    meta: getRouteMeta({
      label: "About Us",
      iconClass: "",
      requiresAuth: false
    })
  },
  {
    path: "/:pathMatch(.*)*",
    component: NotFound,
    name: "notfound",
    meta: getRouteMeta({
      label: "Not Found",
      iconClass: "",
      requiresAuth: false
    })
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

router.beforeEach((to, from, next) => {
  const requiresAuth = to.matched.some((record) => record.meta.requiresAuth);
  const authStore = useAuthStore();
  const isAuthenticated = !!authStore.user;

  if (requiresAuth && !isAuthenticated) {
    next({ name: "login" });
  }
  else {
    next();
  }
  //useRouter().currentRoute.value.meta.name
});

export default router;

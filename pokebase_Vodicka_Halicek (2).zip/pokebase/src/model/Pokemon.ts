export interface Pokemon {
  id?: number;
  name: string;
  // TODO: Add more specs
}

export enum SelectionAnswerType {
    Radio,
    Multi
}

export type FixedArray<N extends number, T> = N extends 0 ? never[] : {
    0: T;
    length: N;
} & ReadonlyArray<T>;
/*
export interface Quiz {
    id: number;
    typeName: string
    title: string;
    context: string;
    sprite: string;
}

export interface QuizRadio extends Quiz {
    typeName: 'QuizRadio'
    answers: Array<{answer: string}>;
    correctAnswer: number;
}

export interface QuizMulti extends Quiz {
    answers: Array<{answer: string}>;
    correctAnswer: Array<{variant: number}>
}

export interface QuizText extends Quiz {
    answer: string;
    correctAnswer: Array<{variant: string}>;
}

export interface QuizError extends Quiz {
    msg: string;
}
*/

export const enum QuizType {
    QT_RADIO,
    QT_TEXT,
    QT_ERROR
}

abstract class AbstractQuiz {
    public id: number;
    public readonly typeName: QuizType;
    public title: string;
    public context: string;
    public sprite: string;

    constructor(
        id: number,
        typeName: QuizType,
        title: string,
        context: string,
        sprite: string
    ) {
        this.id = id;
        this.typeName = typeName;
        this.title = title;
        this.context = context;
        this.sprite = sprite;
    }

    abstract resetUserInput(): any;
}

export class QuizRadio extends AbstractQuiz {
    public answers: Array<{answer: string}>;
    public correctAnswer: number;
    public userSelection: number;

    constructor(parameters: {
        id: number,
        title: string,
        context: string,
        sprite: string,
        answers: Array<{answer: string}>,
        correctAnswer: number
    }) {
        super(parameters.id, QuizType.QT_RADIO, parameters.title, parameters.context, parameters.sprite);
        this.answers = parameters.answers
        this.correctAnswer = parameters.correctAnswer
        this.userSelection = -1
    }

    resetUserInput() {
        this.userSelection = -1
    }
}

export class QuizText extends AbstractQuiz {
    public answer: string;
    public correctAnswer: Array<{variant: string}>;
    public userAnswer: string

    constructor(parameters: {
        id: number,
        title: string,
        context: string,
        sprite: string,
        answer: string,
        correctAnswer: Array<{variant: string}>
    }) {
        super(parameters.id, QuizType.QT_TEXT, parameters.title, parameters.context, parameters.sprite);
        this.answer = parameters.answer
        this.correctAnswer = parameters.correctAnswer
        this.userAnswer = ''
    }

    resetUserInput() {
        this.userAnswer = ''
    }
}

export class QuizError extends AbstractQuiz {
    public msg: string;

    constructor(parameters: {
        id: number,
        title: string,
        context: string,
        sprite: string,
        msg: string
    }) {
        super(parameters.id, QuizType.QT_ERROR, parameters.title, parameters.context, parameters.sprite);
        this.msg = parameters.msg
    }

    resetUserInput() {
        console.log('Calling resetUserInput from Error quiz!')
    }
}
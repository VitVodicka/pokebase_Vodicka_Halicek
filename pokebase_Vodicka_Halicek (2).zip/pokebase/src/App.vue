<template>
  <v-app>

    <v-main>
      <NavigationDrawer class="position-fixed w-100 h-100" :title="getMetaName()">
        <template v-slot:page-contents>
          <router-view />
        </template>
      </NavigationDrawer>
    </v-main>
  </v-app>
</template>

<script setup lang="ts">
  import NavigationDrawer from "@/components/NavigationDrawer.vue";
  import { onMounted } from "vue";
  import { useAuthStore } from "@/stores/auth";
  import { useRouter } from "vue-router";

  const router = useRouter();
  const authStore = useAuthStore();

  onMounted(() => {
    authStore.reloadUser();
  });

  function getMetaName(): string {
    const metaName = router.currentRoute.value.meta.label;
    
    if (typeof metaName === 'string') {
      return metaName;
    }
    else {
      return 'error-type';
    }
  };
</script>
